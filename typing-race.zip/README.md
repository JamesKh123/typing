# Typing Race (Node.js + Socket.IO)

Simple typing race demo that supports rooms and real-time leaderboard.  
This repository is GitHub-ready and can be deployed to Render (recommended) or any Node.js host.

## What's included
- `server.js` - Express + Socket.IO server that manages rooms and leaderboards
- `public/` - Static client (index.html, client.js)
- `package.json` - dependencies and start script

## Quick local run
1. Install Node.js (v18 recommended)
2. Install deps:
   ```
   npm install
   ```
3. Run:
   ```
   npm start
   ```
4. Open http://localhost:3000 and create/join a room.

## Deploy to Render (recommended, free tier)
1. Create a GitHub repo and push this project (instructions below).
2. Go to https://dashboard.render.com -> New -> Web Service
3. Connect your GitHub repo, pick the branch, set the build command to `npm install` and start command to `npm start`.
4. Render will detect and deploy. Set env var `PORT` if needed (Render sets automatically).

## Deploy to Fly / Railway / Heroku
- Works similarly: push to provider-connected GitHub repo and set start command `npm start`.

## Notes & next steps
- This is a minimal demo. For production usage with 100+ players concurrently, consider:
  - Using Redis adapter for Socket.IO when running multiple instances.
  - Throttle/batch broadcasts more aggressively.
  - Persist results in a database (Postgres) if you want history.
  - Add room password, nicer UI (Tailwind), and localization.

## GitHub push example
```
git init
git add .
git commit -m "Initial commit - typing race"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

That's it — enjoy! If you want, I can also directly create a zip you can upload to GitHub or generate the exact render deployment steps.
